# deezer-grabber
Download any track from deezer in flac quality for free without authorization

To use this script you must install:
* requests
* transliterate
* deezer-python
* mutagen
